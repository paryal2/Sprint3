# Local Event Finder

Project Title: Local Event Finder Website

Team Members: Md Hasan, Francisco Vazquez, Kevwe Ogbighen, Luna Da Silva, Prakriti Aryal     

### Description of How to Compile and Run Your Code 

1. Ensure you have Node.js and npm installed on your machine.
2. Make sure your database is connected and your backend is running.
3. Compile the files.
4. Run the React app. 
